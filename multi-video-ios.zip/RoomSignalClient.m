//
//  RoomSignalClient.m
//  AppRTC
//
//  Created by gara on 17/4/15.
//  Copyright © 2017年 ISBX. All rights reserved.
//

#import "RoomSignalClient.h"
#import "RoomUser.h"

static NSString *kSignalUrl = @"http://192.168.1.100:8080/";
@interface RoomSignalClient() {
    dispatch_queue_t _queue;
}
@property (nonatomic, assign) int myUserId;
@property (nonatomic, strong) NSString *roomName;
@property (nonatomic, assign) BOOL isGetSdpCandidate;

@end
@implementation RoomSignalClient

- (instancetype)init
{
    self = [super init];
    if(self) {
        _queue = dispatch_queue_create("com.dispatch.serial.signal", DISPATCH_QUEUE_SERIAL);
    }
    return self;
}

- (void)joinRoom:(NSString*)roomName
{
    _roomName = roomName;
    dispatch_async(_queue, ^{
        NSDictionary *dic = @{@"room_name": roomName};
        NSDictionary *response = [self postRequest:@"join" dic:dic];
        if (response) {
            int error = [response[@"error"] intValue];
            if (error == 0) {
                int myUid = (int)[response[@"my_user_id"] integerValue];
                NSArray *array = response[@"other_user_id"];
                NSMutableArray *otherUserArray = [[NSMutableArray alloc] init];
                for (NSDictionary *subdic in array) {
                    int uid = (int)[subdic[@"room_user_id"] integerValue];
                    RoomUser *ru = [[RoomUser alloc] init];
                    ru.userid = uid;
                    [otherUserArray addObject:ru];
                }
                _myUserId = myUid;
                [_delegate onJoinRoom:error myUserId:myUid other:otherUserArray];
            } else {
                [_delegate onJoinRoom:error myUserId:0 other:nil];
            }
        } else {
            [_delegate onJoinRoom:-1 myUserId:0 other:nil];
        }
    });
}

- (void)leaveRoom:(NSString*)roomName
{
    _roomName = roomName;
    dispatch_async(_queue, ^{
        NSDictionary *dic = @{@"room_name": roomName,
                              @"src_user_id": @(_myUserId)};
        NSDictionary *response = [self postRequest:@"leave" dic:dic];
        if (response) {
            int error = [response[@"error"] intValue];
            [_delegate onDisJoinRoom:error];
        } else {
            [_delegate onDisJoinRoom:-1];
        }
    });
}

- (void)sendSdp:(RTCSessionDescription*)sdp isInitiator:(BOOL)isInitiator dstUserId:(int)dstUserId
{
    dispatch_async(_queue, ^{
        NSDictionary *dic = @{@"src_user_id": @(_myUserId), @"dst_user_id": @(dstUserId), @"room_name": (self.roomName ? self.roomName : @""), @"is_initiator": @(isInitiator?1:0), @"sdp_type": sdp.type, @"sdp_description": sdp.description};
        NSDictionary *response = [self postRequest:@"sdp" dic:dic];
        if (response) {
            int error = [response[@"error"] intValue];
            [_delegate onSendSdp:error];
        } else {
            [_delegate onSendSdp:-1];
        }
    });
}

- (void)sendCandidate:(RTCICECandidate*)candidate isInitiator:(BOOL)isInitiator dstUserId:(int)dstUserId
{
    dispatch_async(_queue, ^{
        NSDictionary *dic = @{@"src_user_id": @(_myUserId), @"dst_user_id": @(dstUserId), @"room_name": (self.roomName ? self.roomName : @""), @"is_initiator": @(isInitiator?1:0), @"ice_sdp_mid": candidate.sdpMid, @"ice_sdp": candidate.sdp, @"ice_sdp_m_line_index": @(candidate.sdpMLineIndex)};
        NSDictionary *response = [self postRequest:@"candidate" dic:dic];
        if (response) {
            int error = [response[@"error"] intValue];
            [_delegate onSendCandidate:error];
        } else {
            [_delegate onSendCandidate:-1];
        }
    });
}

- (void)startGetSdpCandidate {
    _isGetSdpCandidate = YES;
    [self getSdpCandidate];
}

- (void)stopGetSdpCandidate {
    _isGetSdpCandidate = NO;
}

- (void)getSdpCandidate {
    dispatch_async(_queue, ^{
        NSDictionary *dic = @{@"dst_user_id": @(_myUserId), @"room_name": (self.roomName ? self.roomName : @"")};
        NSDictionary *response = [self postRequest:@"get_sdp_candidate" dic:dic];
        if (response) {
            int error = [response[@"error"] intValue];
            if (error == 0) {
                NSArray *array = response[@"sdp_list"];
                for (NSDictionary *subdic in array) {
                    int srcUserId = (int)[subdic[@"src_user_id"] integerValue];
                    NSString *sdpType = subdic[@"sdp_type"];
                    NSString *sdpDescription = subdic[@"sdp_description"];
                    RTCSessionDescription *sdp = [[RTCSessionDescription alloc] initWithType:sdpType sdp:sdpDescription];
                    [_delegate onGetSdp:srcUserId sdp:sdp];
                }
                array = response[@"ice_list_json"];
                for (NSDictionary *subdic in array) {
                    int srcUserId = (int)[subdic[@"src_user_id"] integerValue];
                    NSString *iceSdpMid = subdic[@"ice_sdp_mid"];
                    NSString *iceSdp = subdic[@"ice_sdp"];
                    int mLineIndex = (int)[subdic[@"ice_sdp_m_line_index"] integerValue];
                    RTCICECandidate *candidate = [[RTCICECandidate alloc] initWithMid:iceSdpMid index:mLineIndex sdp:iceSdp];
                    [_delegate onGetCandidate:srcUserId candidate:candidate];
                }
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self performSelector:@selector(getSdpCandidate) withObject:nil afterDelay:3.0];
        });
    });
}

- (NSDictionary*)postRequest:(NSString*)strUrl dic:(NSDictionary*)dic
{
    NSLog(@"postRequest:%@, dic:%@", strUrl, dic);
    // 1.URL
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@", kSignalUrl, strUrl]];
    // 2.请求
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"POST";
    NSData *data = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    request.HTTPBody = data;
    
    // 3.发送请求
    NSError *connectionError = nil;
    NSData *retdata = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&connectionError];
    
    NSLog(@"postRequest connectionError:%@", connectionError);
    if (!connectionError) {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:retdata options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"postRequest response:%@", dic);
        return dic;
    } else {
        return nil;
    }
}
@end
