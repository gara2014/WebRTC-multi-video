//
//  WebRTCClient.h
//  AppRTC
//
//  Created by gara on 17/4/12.
//  Copyright © 2017年 ISBX. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <RTCAVFoundationVideoSource.h>
#import <RTCAudioSource.h>
#import <RTCAudioTrack.h>
#import <RTCDataChannel.h>
#import <RTCEAGLVideoView.h>

#import <RTCFileLogger.h>
#import <RTCLogging.h>

#import <RTCI420Frame.h>

#import <RTCICECandidate.h>
#import <RTCICEServer.h>

#import <RTCMediaConstraints.h>
#import <RTCMediaStream.h>
#import <RTCMediaStreamTrack.h>
//#import <RTCNSGLVideoView.h>

#import <RTCOpenGLVideoRenderer.h>
#import <RTCPair.h>

#import <RTCPeerConnection.h>
#import <RTCPeerConnectionDelegate.h>
#import <RTCPeerConnectionFactory.h>
#import <RTCPeerConnectionInterface.h>

#import <RTCSessionDescription.h>
#import <RTCSessionDescriptionDelegate.h>

#import <RTCStatsDelegate.h>
#import <RTCStatsReport.h>

#import <RTCTypes.h>
#import <RTCVideoCapturer.h>
#import <RTCVideoRenderer.h>
#import <RTCVideoSource.h>
#import <RTCVideoTrack.h>

typedef NS_ENUM(NSInteger, WebRTCClientState) {
    // Disconnected from servers.
    kARDAppClientStateDisconnected,
    // Connecting to servers.
    kARDAppClientStateConnecting,
    // Connected to servers.
    kARDAppClientStateConnected,
};

@protocol WebRTCClientDelegate;
@interface WebRTCClient : NSObject

- (void)createPeerConnection:(RTCEAGLVideoView*)localRender remoteRender:(RTCEAGLVideoView*)remoteRender videoCapturer:(RTCVideoCapturer*)videoCapturer remoteUserId:(int)remoteUserId isInitiator:(BOOL)isInitiator roomName:(NSString*)roomName;
- (void)createAnswer;
- (void)setRemoteDescription:(RTCSessionDescription*)description;
- (void)addRemoteIceCandidate:(RTCICECandidate*) candidate;
- (void)disconnect;

@property (nonatomic, weak) id<WebRTCClientDelegate> delegate;
@property(nonatomic, assign) BOOL isInitiator;
@property (nonatomic, assign) int remoteUserId;
@end

@protocol WebRTCClientDelegate <NSObject>

- (void)onPeerConnectionError:(int)remoteUserId isInitiator:(BOOL)isInitiator s:(NSString*)s;

- (void)onIceCandidate:(int)remoteUserId isInitiator:(BOOL)isInitiator candidate:(RTCICECandidate*)candidate;

- (void)onIceCandidatesRemoved:(int)remoteUserId isInitiator:(BOOL)isInitiator candidates:(NSArray*)candidates;

- (void)onIceConnected:(int)remoteUserId isInitiator:(BOOL)isInitiator;

- (void)onIceDisconnected:(int)remoteUserId isInitiator:(BOOL)isInitiator;

- (void)onLocalDescription:(int)remoteUserId isInitiator:(BOOL)isInitiator localSdp:(RTCSessionDescription*)localSdp;

@end
