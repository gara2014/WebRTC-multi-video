//
//  RoomViewController.m
//  AppRTC
//
//  Created by gara on 17/4/15.
//  Copyright © 2017年 ISBX. All rights reserved.
//

#import "RoomViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <RTCEAGLVideoView.h>
#import "RoomSignalClient.h"
#import "WebRTCClient.h"
#import "RoomUser.h"

static int Max_Remote_Count = 3;
@interface RoomViewController()<RoomSignalDelegate, WebRTCClientDelegate>
@property (nonatomic, assign) int myUserId;
@property (nonatomic, strong) RTCVideoCapturer *videoCapturer;
@property (strong, nonatomic) IBOutlet RTCEAGLVideoView *remote1View;
@property (strong, nonatomic) IBOutlet RTCEAGLVideoView *remote2View;
@property (strong, nonatomic) IBOutlet RTCEAGLVideoView *remote3View;
@property (strong, nonatomic) IBOutlet RTCEAGLVideoView *localView;
@property (nonatomic, strong) RoomSignalClient *signalClient;
@property (nonatomic, strong) NSMutableArray *webRTCClients;

@end
@implementation RoomViewController

- (void)dealloc
{
    [self disconnect];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _signalClient = [[RoomSignalClient alloc] init];
    _signalClient.delegate = self;
    _webRTCClients = [[NSMutableArray alloc] init];
    
    // 发进入房间的消息
    [_signalClient joinRoom:_roomName];
}

- (void)viewDidLayoutSubviews
{
    CGSize size = CGSizeMake((self.view.frame.size.width - 10) / 2, (self.view.frame.size.height - 64 - 10 ) / 2);
    self.remote1View.frame = CGRectMake(0, 64, size.width, size.height);
    self.remote2View.frame = CGRectMake(size.width + 10, 64, size.width, size.height);
    self.remote3View.frame = CGRectMake(0, 64 + size.height + 10, size.width, size.height);
    self.localView.frame = CGRectMake(size.width + 10, 64 + size.height + 10, size.width, size.height);
}

- (RTCVideoCapturer*)createVideoCapturer
{
#if !TARGET_IPHONE_SIMULATOR && TARGET_OS_IPHONE
    NSString *cameraID = nil;
    for (AVCaptureDevice *captureDevice in
         [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo]) {
        if (captureDevice.position == AVCaptureDevicePositionFront) {
            cameraID = [captureDevice localizedName];
            break;
        }
    }
    NSAssert(cameraID, @"Unable to get the front camera id");
    
    return [RTCVideoCapturer capturerWithDeviceName:cameraID];
#endif
    
    return NULL;
}

- (void)disconnect {
    [_signalClient stopGetSdpCandidate];
    [_signalClient leaveRoom:_roomName];
    for (WebRTCClient *webRTCClient in _webRTCClients) {
        [webRTCClient disconnect];
    }
    [_localView renderFrame:nil];
    [_remote1View renderFrame:nil];
    [_remote2View renderFrame:nil];
    [_remote3View renderFrame:nil];
    [_webRTCClients removeAllObjects];
}

#pragma RoomSignalDelegate
- (void)onJoinRoom:(int)error myUserId:(int)myUserId other:(NSArray*)/*RoomUser*/ other
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (error == 0) {
            _videoCapturer = [self createVideoCapturer];
            _myUserId = myUserId;
            NSArray* array = @[_remote1View, _remote2View, _remote3View];
            for (int i = 0;i < other.count && _webRTCClients.count < Max_Remote_Count; i++) {
                RoomUser *ru = [other objectAtIndex:i];
                WebRTCClient *webRTCClient = [[WebRTCClient alloc] init];
                webRTCClient.delegate = self;
                [webRTCClient createPeerConnection:_localView remoteRender:array[_webRTCClients.count] videoCapturer:_videoCapturer remoteUserId:ru.userid isInitiator:YES roomName:_roomName];
                [_webRTCClients addObject:webRTCClient];
            }
            
            [_signalClient startGetSdpCandidate];
        }
    });
}

- (void)onSendSdp:(int)error
{
    
}

- (void)onSendCandidate:(int)error
{
    
}

- (void)onGetSdp:(int)srcUserId sdp:(RTCSessionDescription*)sdp
{
    dispatch_async(dispatch_get_main_queue(), ^{
        BOOL find = NO;
        for (int i = 0; i < _webRTCClients.count; i++) {
            WebRTCClient *webRTCClient = [_webRTCClients objectAtIndex:i];
            if (webRTCClient.remoteUserId == srcUserId) {
                find = YES;
                [webRTCClient setRemoteDescription:sdp];
                if (!webRTCClient.isInitiator) {
                    [webRTCClient createAnswer];
                }
                break;
            }
        }
        // 没找到sdp，说明是在我后面加入房间，对方是initiator
        if (!find && _webRTCClients.count < Max_Remote_Count) {
            WebRTCClient *webRTCClient = [[WebRTCClient alloc] init];
            webRTCClient.delegate = self;
            NSArray* array = @[_remote1View, _remote2View, _remote3View];
            [webRTCClient createPeerConnection:_localView remoteRender:array[_webRTCClients.count] videoCapturer:_videoCapturer remoteUserId:srcUserId isInitiator:NO roomName:_roomName];
            [_webRTCClients addObject:webRTCClient];
            [webRTCClient setRemoteDescription:sdp];
            if (!webRTCClient.isInitiator) {
                [webRTCClient createAnswer];
            }
        }
    });
}

- (void)onGetCandidate:(int)srcUserId candidate:(RTCICECandidate*)candidate
{
    dispatch_async(dispatch_get_main_queue(), ^{
        BOOL find = NO;
        for (int i = 0; i < _webRTCClients.count; i++) {
            WebRTCClient *webRTCClient = [_webRTCClients objectAtIndex:i];
            if (webRTCClient.remoteUserId == srcUserId) {
                find = YES;
                [webRTCClient addRemoteIceCandidate:candidate];
                break;
            }
        }
        // 没找到sdp，说明是在我后面加入房间，对方是initiator
        if (!find && _webRTCClients.count < Max_Remote_Count) {
            WebRTCClient *webRTCClient = [[WebRTCClient alloc] init];
            webRTCClient.delegate = self;
            NSArray* array = @[_remote1View, _remote2View, _remote3View];
            [webRTCClient createPeerConnection:_localView remoteRender:array[_webRTCClients.count] videoCapturer:_videoCapturer remoteUserId:srcUserId isInitiator:NO roomName:_roomName];
            [_webRTCClients addObject:webRTCClient];
            [webRTCClient addRemoteIceCandidate:candidate];
        }
    });
}

- (void)onDisJoinRoom:(int)error
{
    
}

#pragma WebRTCClientDelegate
- (void)onPeerConnectionError:(int)remoteUserId isInitiator:(BOOL)isInitiator s:(NSString*)s
{
    
}

- (void)onIceCandidate:(int)remoteUserId isInitiator:(BOOL)isInitiator candidate:(RTCICECandidate*)candidate
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [_signalClient sendCandidate:candidate isInitiator:isInitiator dstUserId:remoteUserId];
    });
}

- (void)onIceCandidatesRemoved:(int)remoteUserId isInitiator:(BOOL)isInitiator candidates:(NSArray*)candidates
{
    
}

- (void)onIceConnected:(int)remoteUserId isInitiator:(BOOL)isInitiator
{
    
}

- (void)onIceDisconnected:(int)remoteUserId isInitiator:(BOOL)isInitiator
{
    dispatch_async(dispatch_get_main_queue(), ^{
        for (int i = 0; i < _webRTCClients.count; i++) {
            WebRTCClient *webRTCClient = [_webRTCClients objectAtIndex:i];
            if (webRTCClient.remoteUserId == remoteUserId) {
                [_webRTCClients removeObjectAtIndex:i];
                [webRTCClient disconnect];
                break;
            }
        }
    });
}

- (void)onLocalDescription:(int)remoteUserId isInitiator:(BOOL)isInitiator localSdp:(RTCSessionDescription*)localSdp
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [_signalClient sendSdp:localSdp isInitiator:isInitiator dstUserId:remoteUserId];
    });
}

@end
