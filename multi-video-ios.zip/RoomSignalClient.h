//
//  RoomSignalClient.h
//  AppRTC
//
//  Created by gara on 17/4/15.
//  Copyright © 2017年 ISBX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RTCSessionDescription.h>
#import <RTCICECandidate.h>
@protocol RoomSignalDelegate;
@interface RoomSignalClient : NSObject

- (void)joinRoom:(NSString*)roomName;
- (void)leaveRoom:(NSString*)roomName;
- (void)sendSdp:(RTCSessionDescription*)sdp isInitiator:(BOOL)isInitiator dstUserId:(int)dstUserId;
- (void)sendCandidate:(RTCICECandidate*)candidate isInitiator:(BOOL)isInitiator dstUserId:(int)dstUserId;
- (void)startGetSdpCandidate;
- (void)stopGetSdpCandidate;

@property (nonatomic, weak) id<RoomSignalDelegate> delegate;

@end

@protocol RoomSignalDelegate <NSObject>

- (void)onJoinRoom:(int)error myUserId:(int)myUserId other:(NSArray*)/*RoomUser*/ other;

- (void)onSendSdp:(int)error;

- (void)onSendCandidate:(int)error;

- (void)onGetSdp:(int)srcUserId sdp:(RTCSessionDescription*)sdp;

- (void)onGetCandidate:(int)srcUserId candidate:(RTCICECandidate*)candidate;

- (void)onDisJoinRoom:(int)error;

@end
