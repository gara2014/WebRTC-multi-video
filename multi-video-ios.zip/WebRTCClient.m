//
//  WebRTCClient.m
//  AppRTC
//
//  Created by gara on 17/4/12.
//  Copyright © 2017年 ISBX. All rights reserved.
//

#import "WebRTCClient.h"
#import <AVFoundation/AVFoundation.h>


//static NSString *kARDDefaultSTUNServerUrl = @"stun:stun.l.google.com:19302";
static NSString *kARDDefaultSTUNServerUrl = @"stun:121.40.91.37:3478";
@interface WebRTCClient() <RTCPeerConnectionDelegate, RTCSessionDescriptionDelegate> {
    dispatch_queue_t _queue;
}

@property(nonatomic, strong) RTCPeerConnection *peerConnection;
@property(nonatomic, strong) RTCPeerConnectionFactory *factory;
@property(nonatomic, strong) NSMutableArray *iceServers;
@property(nonatomic, assign) BOOL isSpeakerEnabled;

@property (nonatomic, strong) NSString *roomName;
@property (nonatomic, weak) RTCEAGLVideoView *localRender;
@property (nonatomic, weak) RTCEAGLVideoView *remoteRender;
@property (nonatomic, weak) RTCVideoCapturer *videoCapturer;
@property (nonatomic, strong) RTCVideoTrack *localVideoTrack;
@property (nonatomic, strong) RTCVideoTrack *remoteVideoTrack;
@property (nonatomic, strong) RTCSessionDescription *localSdp;

@end
@implementation WebRTCClient

- (instancetype)init {
    self = [super init];
    if (self) {
        _queue = dispatch_queue_create("com.dispatch.serial.WebRTCClient", DISPATCH_QUEUE_SERIAL);
        _factory = [[RTCPeerConnectionFactory alloc] init];
        _iceServers = [NSMutableArray arrayWithObject:[self defaultSTUNServer]];
        _isSpeakerEnabled = YES;
    }
    return self;
}

- (void)createPeerConnection:(RTCEAGLVideoView*)localRender remoteRender:(RTCEAGLVideoView*)remoteRender videoCapturer:(RTCVideoCapturer*)videoCapturer remoteUserId:(int)remoteUserId isInitiator:(BOOL)isInitiator roomName:(NSString*)roomName
{
    dispatch_async(_queue, ^{
        _localRender = localRender;
        _remoteRender = remoteRender;
        _videoCapturer = videoCapturer;
        _remoteUserId = remoteUserId;
        _isInitiator = isInitiator;
        _roomName = roomName;
        // Create peer connection.
        RTCMediaConstraints *constraints = [self defaultPeerConnectionConstraints];
        _peerConnection = [_factory peerConnectionWithICEServers:_iceServers
                                                     constraints:constraints
                                                        delegate:self];
        RTCMediaStream *localStream = [self createLocalMediaStream];
        [_peerConnection addStream:localStream];
        if (_isInitiator) {
            [self createOffer];
        }
    });
}

- (void)createOffer {
    [_peerConnection createOfferWithDelegate:self
                                 constraints:[self defaultOfferConstraints]];
}

- (void)createAnswer {
    dispatch_async(_queue, ^{
        [_peerConnection createAnswerWithDelegate:self constraints:[self defaultAnswerConstraints]];
    });
}

- (RTCMediaConstraints *)defaultAnswerConstraints {
    return [self defaultOfferConstraints];
}

- (RTCMediaConstraints *)defaultOfferConstraints {
    NSArray *mandatoryConstraints = @[
                                      [[RTCPair alloc] initWithKey:@"OfferToReceiveAudio" value:@"true"],
                                      [[RTCPair alloc] initWithKey:@"OfferToReceiveVideo" value:@"true"]
                                      ];
    RTCMediaConstraints *constraints =
    [[RTCMediaConstraints alloc]
     initWithMandatoryConstraints:mandatoryConstraints
     optionalConstraints:nil];
    return constraints;
}

- (RTCVideoTrack *)createLocalVideoTrack {
    // The iOS simulator doesn't provide any sort of camera capture
    // support or emulation (http://goo.gl/rHAnC1) so don't bother
    // trying to open a local stream.
    // TODO(tkchin): local video capture for OSX. See
    // https://code.google.com/p/webrtc/issues/detail?id=3417.
    
    RTCVideoTrack *localVideoTrack = nil;
    if (_videoCapturer) {
        RTCMediaConstraints *mediaConstraints = [self defaultMediaStreamConstraints];
        RTCVideoSource *videoSource = [_factory videoSourceWithCapturer:_videoCapturer constraints:mediaConstraints];
        localVideoTrack = [_factory videoTrackWithID:@"ARDAMSv0" source:videoSource];
        [localVideoTrack addRenderer:_localRender];
    }

    return localVideoTrack;
}

- (RTCMediaStream *)createLocalMediaStream {
    RTCMediaStream* localStream = [_factory mediaStreamWithLabel:@"ARDAMS"];
    
    _localVideoTrack = [self createLocalVideoTrack];
    if (_localVideoTrack) {
        [localStream addVideoTrack:_localVideoTrack];
    }
    
    [localStream addAudioTrack:[_factory audioTrackWithID:@"ARDAMSa0"]];
    if (_isSpeakerEnabled) [self enableSpeaker];
    return localStream;
}

- (RTCMediaConstraints *)defaultMediaStreamConstraints {
    RTCMediaConstraints* constraints =
    [[RTCMediaConstraints alloc]
     initWithMandatoryConstraints:nil
     optionalConstraints:nil];
    return constraints;
}

- (RTCMediaConstraints *)defaultPeerConnectionConstraints {
    NSArray *optionalConstraints = @[
                                     [[RTCPair alloc] initWithKey:@"DtlsSrtpKeyAgreement" value:@"true"]
                                     ];
    RTCMediaConstraints* constraints =
    [[RTCMediaConstraints alloc]
     initWithMandatoryConstraints:nil
     optionalConstraints:optionalConstraints];
    return constraints;
}

- (RTCICEServer *)defaultSTUNServer {
    NSURL *defaultSTUNServerURL = [NSURL URLWithString:kARDDefaultSTUNServerUrl];
    return [[RTCICEServer alloc] initWithURI:defaultSTUNServerURL
                                    username:@""
                                    password:@""];
}

- (void)setRemoteDescription:(RTCSessionDescription*)sdp {
    dispatch_async(_queue, ^{
        [_peerConnection setRemoteDescriptionWithDelegate:self sessionDescription:sdp];
    });
}

- (void)addRemoteIceCandidate:(RTCICECandidate*)candidate {
    dispatch_async(_queue, ^{
        [_peerConnection addICECandidate:candidate];
    });
}

- (void)disconnect {
    dispatch_async(_queue, ^{
        [_localVideoTrack removeRenderer:_localRender];
        [_remoteVideoTrack removeRenderer:_remoteRender];
        _remoteUserId = 0;
        _roomName = nil;
        _isInitiator = NO;
        _factory = nil;
        _peerConnection = nil;
    });
}

#pragma mark - RTCPeerConnectionDelegate

- (void)peerConnection:(RTCPeerConnection *)peerConnection
 signalingStateChanged:(RTCSignalingState)stateChanged {
    NSLog(@"Signaling state changed: %d", stateChanged);
}

- (void)peerConnection:(RTCPeerConnection *)peerConnection
           addedStream:(RTCMediaStream *)stream {
    dispatch_async(_queue, ^{
        NSLog(@"Received %lu video tracks and %lu audio tracks",
              (unsigned long)stream.videoTracks.count,
              (unsigned long)stream.audioTracks.count);
        if (stream.videoTracks.count) {
            _remoteVideoTrack = stream.videoTracks[0];
            [_remoteVideoTrack setEnabled:YES];
            [_remoteVideoTrack addRenderer:_remoteRender];
            if (_isSpeakerEnabled) [self enableSpeaker]; //Use the "handsfree" speaker instead of the ear speaker.
            
        }
    });
}

- (void)peerConnection:(RTCPeerConnection *)peerConnection
         removedStream:(RTCMediaStream *)stream {
    NSLog(@"Stream was removed.");
    dispatch_async(_queue, ^{
        _remoteVideoTrack = NULL;
    });
}

- (void)peerConnectionOnRenegotiationNeeded:
(RTCPeerConnection *)peerConnection {
    NSLog(@"WARNING: Renegotiation needed but unimplemented.");
}

- (void)peerConnection:(RTCPeerConnection *)peerConnection
  iceConnectionChanged:(RTCICEConnectionState)newState {
    dispatch_async(_queue, ^{
        NSLog(@"ICE state changed: %d", newState);
        if (newState == RTCICEConnectionConnected) {
            [_delegate onIceConnected:_remoteUserId isInitiator:_isInitiator];
        } else if (newState == RTCICEConnectionDisconnected) {
            [_delegate onIceDisconnected:_remoteUserId isInitiator:_isInitiator];
        } else if (newState == RTCICEConnectionFailed) {
            //reportError("ICE connection failed.");
        }
    });
}

- (void)peerConnection:(RTCPeerConnection *)peerConnection
   iceGatheringChanged:(RTCICEGatheringState)newState {
    NSLog(@"ICE gathering state changed: %d", newState);
}

- (void)peerConnection:(RTCPeerConnection *)peerConnection
       gotICECandidate:(RTCICECandidate *)candidate {
    dispatch_async(_queue, ^{
        [_delegate onIceCandidate:_remoteUserId isInitiator:_isInitiator candidate:candidate];
    });
}

- (void)peerConnection:(RTCPeerConnection*)peerConnection
    didOpenDataChannel:(RTCDataChannel*)dataChannel {
}

#pragma mark - RTCSessionDescriptionDelegate

- (void)peerConnection:(RTCPeerConnection *)peerConnection
didCreateSessionDescription:(RTCSessionDescription *)sdp
                 error:(NSError *)error {
    if (_localSdp) {
        //reportError("Multiple SDP create.");
        return;
    }
    _localSdp = sdp;
    dispatch_async(_queue, ^{
        [_peerConnection setLocalDescriptionWithDelegate:self sessionDescription:sdp];
    });
}

- (void)peerConnection:(RTCPeerConnection *)peerConnection
didSetSessionDescriptionWithError:(NSError *)error {
    dispatch_async(_queue, ^{
        if (_isInitiator) {
            if (peerConnection.remoteDescription == NULL) {
                [_delegate onLocalDescription:_remoteUserId isInitiator:_isInitiator localSdp:_localSdp];
            }
        } else {
            if (peerConnection.localDescription != NULL) {
                [_delegate onLocalDescription:_remoteUserId isInitiator:_isInitiator localSdp:_localSdp];
            }
        }
    });
}
#pragma mark - enable/disable speaker

- (void)enableSpeaker {
    [[AVAudioSession sharedInstance] overrideOutputAudioPort:AVAudioSessionPortOverrideSpeaker error:nil];
    _isSpeakerEnabled = YES;
}

- (void)disableSpeaker {
    [[AVAudioSession sharedInstance] overrideOutputAudioPort:AVAudioSessionPortOverrideNone error:nil];
    _isSpeakerEnabled = NO;
}

@end
