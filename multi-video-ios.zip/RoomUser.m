//
//  RoomUser.m
//  AppRTC
//
//  Created by gara on 17/4/15.
//  Copyright © 2017年 ISBX. All rights reserved.
//

#import "RoomUser.h"

@implementation RoomUser

@end
