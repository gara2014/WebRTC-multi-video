package org.appspot.apprtc;

import org.webrtc.IceCandidate;
import org.webrtc.SessionDescription;

/**
 * Created by gara on 17/4/15.
 */

public interface WebRTCClientEvents {
    void onPeerConnectionError(final int remoteUserId, final boolean isInitiator, final String s);

    void onIceCandidate(final int remoteUserId, final boolean isInitiator, final IceCandidate candidate);

    void onIceCandidatesRemoved(final int remoteUserId, final boolean isInitiator, final IceCandidate[] candidates);

    void onIceConnected(final int remoteUserId, final boolean isInitiator);

    void onIceDisconnected(final int remoteUserId, final boolean isInitiator);

    void onLocalDescription(final int remoteUserId, final boolean isInitiator, final SessionDescription localSdp);
}
