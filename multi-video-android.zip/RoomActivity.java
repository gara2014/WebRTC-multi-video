package org.appspot.apprtc;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import org.webrtc.Camera1Enumerator;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraEnumerator;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.Logging;
import org.webrtc.RendererCommon;
import org.webrtc.ScreenCapturerAndroid;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoCapturer;

import java.util.LinkedList;
import java.util.List;

//gara test only 有可能人进来立即出去
public class RoomActivity extends Activity implements RoomSignalEvents, WebRTCClientEvents {
    private static String TAG = "RoomActivity";
    private List<WebRTCClient> webRTCClients;
    private RoomSignalClient signalClient;
    private String roomName;
    private int myUserId;
    VideoCapturer videoCapturer;
    private SurfaceViewRenderer localRender;
    private static int Max_Remote_Count = 3;
    private SurfaceViewRenderer[] remoteRenders;
    private PercentFrameLayout localRenderLayout;
    private PercentFrameLayout[] remoteRenderLayouts;
    private EglBase rootEglBase;
    // List of mandatory application permissions.
    private static final String[] MANDATORY_PERMISSIONS = {"android.permission.MODIFY_AUDIO_SETTINGS",
            "android.permission.RECORD_AUDIO", "android.permission.INTERNET"};
    private Toast logToast;
    private boolean screencaptureEnabled = false;
    private static Intent mediaProjectionPermissionResultData;
    private static int mediaProjectionPermissionResultCode;
    private static final int CAPTURE_PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room);
        final Intent intent = getIntent();
        roomName = intent.getStringExtra("roomName");
        signalClient = new RoomSignalClient(this);
        webRTCClients = new LinkedList<>();
        // Check for mandatory permissions.
        //gara test only
//        for (String permission : MANDATORY_PERMISSIONS) {
//            if (checkCallingOrSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
//                //logAndToast("Permission " + permission + " is not granted");
//                setResult(RESULT_CANCELED);
//                finish();
//                return;
//            }
//        }
        // Create UI controls.
        remoteRenders = new SurfaceViewRenderer[Max_Remote_Count];
        remoteRenderLayouts = new PercentFrameLayout[Max_Remote_Count];
        localRender = (SurfaceViewRenderer) findViewById(R.id.local1_video_view);
        remoteRenders[0] = (SurfaceViewRenderer) findViewById(R.id.remote1_video_view);
        remoteRenders[1] = (SurfaceViewRenderer) findViewById(R.id.remote2_video_view);
        remoteRenders[2] = (SurfaceViewRenderer) findViewById(R.id.remote3_video_view);
        localRenderLayout = (PercentFrameLayout) findViewById(R.id.local1_video_layout);
        remoteRenderLayouts[0] = (PercentFrameLayout) findViewById(R.id.remote1_video_layout);
        remoteRenderLayouts[1] = (PercentFrameLayout) findViewById(R.id.remote2_video_layout);
        remoteRenderLayouts[2] = (PercentFrameLayout) findViewById(R.id.remote3_video_layout);
        rootEglBase = EglBase.create();
        localRender.init(rootEglBase.getEglBaseContext(), null);
        localRender.setZOrderMediaOverlay(true);
        localRender.setEnableHardwareScaler(true /* enabled */);
        localRenderLayout.setPosition(
                52, 52, 48, 48);
        localRender.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL);
        localRender.setMirror(true);
        localRender.requestLayout();
        for (int i = 0; i < Max_Remote_Count; i++) {
            remoteRenders[i].init(rootEglBase.getEglBaseContext(), null);
            remoteRenders[i].setEnableHardwareScaler(true /* enabled */);
            remoteRenderLayouts[i].setPosition(52 * (i % 2), 52 * (i / 2), 48, 48);
            remoteRenders[i].setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL);
            remoteRenders[i].setMirror(false);
            remoteRenders[i].requestLayout();
        }

        if (screencaptureEnabled) {
            startScreenCapture();
        } else {
            // 发进入房间的消息
            signalClient.joinRoom(roomName);
        }
    }

    @Override
    protected void onDestroy() {
        disconnect();
        if (logToast != null) {
            logToast.cancel();
        }
        if (rootEglBase != null) {
            rootEglBase.release();
        }
        super.onDestroy();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != CAPTURE_PERMISSION_REQUEST_CODE)
            return;
        mediaProjectionPermissionResultCode = resultCode;
        mediaProjectionPermissionResultData = data;
        // 发进入房间的消息
        signalClient.joinRoom(roomName);
    }

    private void startScreenCapture() {
        MediaProjectionManager mediaProjectionManager =
                (MediaProjectionManager) getApplication().getSystemService(
                        Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(
                mediaProjectionManager.createScreenCaptureIntent(), CAPTURE_PERMISSION_REQUEST_CODE);
    }

    private VideoCapturer createCameraCapturer(CameraEnumerator enumerator) {
        final String[] deviceNames = enumerator.getDeviceNames();

        // First, try to find front facing camera
        Logging.d(TAG, "Looking for front facing cameras.");
        for (String deviceName : deviceNames) {
            if (enumerator.isFrontFacing(deviceName)) {
                Logging.d(TAG, "Creating front facing camera capturer.");
                VideoCapturer videoCapturer = enumerator.createCapturer(deviceName, null);

                if (videoCapturer != null) {
                    return videoCapturer;
                }
            }
        }

        // Front facing camera not found, try something else
        Logging.d(TAG, "Looking for other cameras.");
        for (String deviceName : deviceNames) {
            if (!enumerator.isFrontFacing(deviceName)) {
                Logging.d(TAG, "Creating other camera capturer.");
                VideoCapturer videoCapturer = enumerator.createCapturer(deviceName, null);

                if (videoCapturer != null) {
                    return videoCapturer;
                }
            }
        }

        return null;
    }

    private VideoCapturer createScreenCapturer() {
        if (mediaProjectionPermissionResultCode != Activity.RESULT_OK) {
            reportError("User didn't give permission to capture the screen.");
            return null;
        }
        return new ScreenCapturerAndroid(
                mediaProjectionPermissionResultData, new MediaProjection.Callback() {
            @Override
            public void onStop() {
                reportError("User revoked permission to capture the screen.");
            }
        });
    }

    private VideoCapturer createVideoCapturer() {
        VideoCapturer videoCapturer = null;
        if (screencaptureEnabled) {
            return createScreenCapturer();
        } else if (Camera2Enumerator.isSupported(this)) {

            Logging.d(TAG, "Creating capturer using camera2 API.");
            videoCapturer = createCameraCapturer(new Camera2Enumerator(this));
        } else {
            Logging.d(TAG, "Creating capturer using camera1 API.");
            videoCapturer = createCameraCapturer(new Camera1Enumerator(false));
        }
        if (videoCapturer == null) {
            reportError("Failed to open camera");
            return null;
        }
        return videoCapturer;
    }

    private void reportError(final String description) {
        Log.d(TAG, "reportError: " + description);
    }

    // Log |msg| and Toast about it.
    private void logAndToast(String msg) {
        Log.d(TAG, msg);
        if (logToast != null) {
            logToast.cancel();
        }
        logToast = Toast.makeText(this, msg, Toast.LENGTH_SHORT);
        logToast.show();
    }

    // Disconnect from remote resources, dispose of local resources, and exit.
    private void disconnect() {
        if (signalClient != null) {
            signalClient.leaveRoom(roomName);
            signalClient.stopGetSdpCandidate();
            signalClient = null;
        }
        if (webRTCClients != null) {
            for (int i = 0;i < webRTCClients.size(); i++) {
                WebRTCClient webRTCClient = webRTCClients.get(i);
                webRTCClient.close();
            }
            webRTCClients = null;
        }
        if (videoCapturer != null) {
            try {
                videoCapturer.stopCapture();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            videoCapturer.dispose();
            videoCapturer = null;
        }
        if (localRender != null) {
            localRender.release();
            localRender = null;
        }
        if (remoteRenders != null) {
            for (int i = 0; i < Max_Remote_Count; i++) {
                if (remoteRenders[i] != null) {
                    remoteRenders[i].release();
                    remoteRenders[i] = null;
                }
            }
        }
        finish();
    }

    // RoomSignalEvents
    @Override
    public void onJoinRoom(final int error, final int myUserId, final List<RoomUser> other) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (error == 0) {
                    videoCapturer = createVideoCapturer();
                    RoomActivity.this.myUserId = myUserId;
                    for (int i = 0;i < other.size() && webRTCClients.size() < Max_Remote_Count; i++) {
                        RoomUser ru = other.get(i);
                        WebRTCClient webRTCClient = new WebRTCClient(RoomActivity.this);
                        webRTCClient.createPeerConnection(rootEglBase.getEglBaseContext(),
                                localRender,
                                remoteRenders[webRTCClients.size()],
                                videoCapturer,
                                RoomActivity.this, true, ru.userId, roomName);
                        webRTCClients.add(webRTCClient);
                    }

                    signalClient.startGetSdpCandidate();
                }
            }
        });
    }

    @Override
    public void onSendSdp(final int error) {

    }

    @Override
    public void onSendCandidate(final int error) {

    }

    @Override
    public void onGetSdp(final int srcUserId, final SessionDescription sdp) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                boolean find = false;
                for (int i = 0; i < webRTCClients.size(); i++) {
                    WebRTCClient webRTCClient = webRTCClients.get(i);
                    if (webRTCClient.remoteUserId == srcUserId) {
                        find = true;
                        webRTCClient.setRemoteDescription(sdp);
                        if (!webRTCClient.isInitiator) {
                            logAndToast("Creating ANSWER...");
                            // Create answer. Answer SDP will be sent to offering client in
                            // PeerConnectionEvents.onLocalDescription event.
                            webRTCClient.createAnswer();
                        }
                        break;
                    }
                }
                // 没找到sdp，说明是在我后面加入房间，对方是initiator
                if (!find && webRTCClients.size() < Max_Remote_Count) {
                    WebRTCClient webRTCClient = new WebRTCClient(RoomActivity.this);
                    webRTCClient.createPeerConnection(rootEglBase.getEglBaseContext(),
                            localRender,
                            remoteRenders[webRTCClients.size()],
                            videoCapturer,
                            RoomActivity.this, false, srcUserId, roomName);
                    webRTCClients.add(webRTCClient);
                    webRTCClient.setRemoteDescription(sdp);
                    if (!webRTCClient.isInitiator) {
                        logAndToast("Creating ANSWER...");
                        // Create answer. Answer SDP will be sent to offering client in
                        // PeerConnectionEvents.onLocalDescription event.
                        webRTCClient.createAnswer();
                    }
                }
            }
        });
    }

    @Override
    public void onGetCandidate(final int srcUserId, final IceCandidate candidate) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                boolean find = false;
                for (int i = 0; i < webRTCClients.size(); i++) {
                    WebRTCClient webRTCClient = webRTCClients.get(i);
                    if (webRTCClient.remoteUserId == srcUserId) {
                        find = true;
                        webRTCClient.addRemoteIceCandidate(candidate);
                        break;
                    }
                }
                // 没找到sdp，说明是在我后面加入房间，对方是initiator
                if (!find && webRTCClients.size() < Max_Remote_Count) {
                    WebRTCClient webRTCClient = new WebRTCClient(RoomActivity.this);
                    webRTCClient.createPeerConnection(rootEglBase.getEglBaseContext(),
                            localRender,
                            remoteRenders[webRTCClients.size()],
                            videoCapturer,
                            RoomActivity.this, false, srcUserId, roomName);
                    webRTCClients.add(webRTCClient);
                    webRTCClient.addRemoteIceCandidate(candidate);
                }
            }
        });
    }

    @Override
    public void onDisJoinRoom(final int error) {

    }

    // WebRTCClientEvents
    @Override
    public void onPeerConnectionError(final int remoteUserId, final boolean isInitiator, final String s) {

    }

    @Override
    public void onIceCandidate(final int remoteUserId, final boolean isInitiator, final IceCandidate candidate) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                signalClient.sendCandidate(candidate, isInitiator, remoteUserId);
            }
        });
    }

    @Override
    public void onIceCandidatesRemoved(final int remoteUserId, final boolean isInitiator, final IceCandidate[] candidates) {

    }

    @Override
    public void onIceConnected(final int remoteUserId, final boolean isInitiator) {

    }

    @Override
    public void onIceDisconnected(final int remoteUserId, final boolean isInitiator) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < webRTCClients.size(); i++) {
                    WebRTCClient webRTCClient = webRTCClients.get(i);
                    if (webRTCClient.remoteUserId == remoteUserId) {
                        webRTCClients.remove(i);
                        webRTCClient.close();
                        break;
                    }
                }
            }
        });
    }

    @Override
    public void onLocalDescription(final int remoteUserId, final boolean isInitiator, final SessionDescription localSdp) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                signalClient.sendSdp(localSdp, isInitiator, remoteUserId);
            }
        });
    }
}
