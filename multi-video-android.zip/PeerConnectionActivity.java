package org.appspot.apprtc;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.Nullable;

import org.webrtc.EglBase;
import org.webrtc.RendererCommon;
import org.webrtc.SurfaceViewRenderer;


public class PeerConnectionActivity extends Activity {
    private WebRTCClient webRTCClient;
    private boolean isInitiator;
    private String roomName;

    private SurfaceViewRenderer localRender;
    private SurfaceViewRenderer remoteRenderScreen;
    private PercentFrameLayout localRenderLayout;
    private PercentFrameLayout remoteRenderLayout;
    private EglBase rootEglBase;
    // List of mandatory application permissions.
    private static final String[] MANDATORY_PERMISSIONS = {"android.permission.MODIFY_AUDIO_SETTINGS",
            "android.permission.RECORD_AUDIO", "android.permission.INTERNET"};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peerconnection);
        final Intent intent = getIntent();
        isInitiator = intent.getBooleanExtra("isInitiator", true);
        roomName = intent.getStringExtra("roomName");
        // Check for mandatory permissions.
        for (String permission : MANDATORY_PERMISSIONS) {
            if (checkCallingOrSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                //logAndToast("Permission " + permission + " is not granted");
                setResult(RESULT_CANCELED);
                finish();
                return;
            }
        }
        // Create UI controls.
        localRender = (SurfaceViewRenderer) findViewById(R.id.peer_local_video_view);
        remoteRenderScreen = (SurfaceViewRenderer) findViewById(R.id.peer_remote_video_view);
        localRenderLayout = (PercentFrameLayout) findViewById(R.id.peer_local_video_layout);
        remoteRenderLayout = (PercentFrameLayout) findViewById(R.id.peer_remote_video_layout);
        rootEglBase = EglBase.create();
        localRender.init(rootEglBase.getEglBaseContext(), null);
        remoteRenderScreen.init(rootEglBase.getEglBaseContext(), null);

        localRender.setZOrderMediaOverlay(true);
        localRender.setEnableHardwareScaler(true /* enabled */);
        remoteRenderScreen.setEnableHardwareScaler(true /* enabled */);
        remoteRenderLayout.setPosition(0, 0, 100, 48);
        remoteRenderScreen.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL);
        remoteRenderScreen.setMirror(false);
        localRenderLayout.setPosition(
                0, 52, 100, 48);
        localRender.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL);
        localRender.setMirror(true);
        localRender.requestLayout();
        remoteRenderScreen.requestLayout();

//        webRTCClient = new WebRTCClient(this);
//        webRTCClient.createPeerConnection(rootEglBase.getEglBaseContext(), localRender,
//                remoteRenderScreen, isInitiator, roomName);

    }
}
