package org.appspot.apprtc;

/**
 * Created by gara on 17/4/15.
 */

public class RoomUser {
    public int userId;

}
